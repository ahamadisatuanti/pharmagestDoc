package example.pharmagest;

import javax.sql.rowset.CachedRowSet;
import java.sql.*;

public class DBUtil {
    private static final String JDBC_DRIVER = "org.postgresql.Driver";
    private static Connection conn = null;
    private static final String connStr = "jdbc:postgresql://localhost:5432/";

    public static void dbConnect(String dbname, String user, String pass) throws SQLException, ClassNotFoundException {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Où est votre pilote JDBC PostGreSQL?");
            e.printStackTrace();
            throw e;
        }

        System.out.println("Pilote JDBC PostGreSQL enregistré!");

        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/" + dbname, user, pass);
        } catch (SQLException e) {
            System.out.println("La connexion a échoué! Vérifiez la console de sortie" + e);
            e.printStackTrace();
            throw e;
        }
        System.out.println(conn);
    }

    public static void dbDisconnect() throws SQLException {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public static ResultSet dbExecuteQuery(String queryStmt) throws SQLException, ClassNotFoundException {
        Statement stmt = null;
        ResultSet resultSet = null;

        try {
            dbConnect("CRUD_DB", "postgres", "1234");
            System.out.println("Déclaration SELECT : " + queryStmt + "\n");
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(queryStmt);
        } catch (SQLException e) {
            System.out.println("Un problème est survenu lors de l'opération executeQuery : " + e);
            throw e;
        } finally {
            // Fermer la connexion dans le bloc finally pour garantir sa fermeture, même en cas d'exception
            dbDisconnect();
        }

        return resultSet;
    }


    public static void dbExecuteUpdate(String sqlStmt) throws SQLException, ClassNotFoundException {
        Statement stmt = null;

        try {
            dbConnect("CRUD_DB", "postgres", "nichico976");
            stmt = conn.createStatement();
            stmt.executeUpdate(sqlStmt);
        } catch (SQLException e) {
            System.out.println("Un problème est survenu lors de l'opération executeUpdate : " + e);
            throw e;
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            dbDisconnect();
        }
    }
}
