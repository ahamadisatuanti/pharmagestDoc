package example.pharmagest;

public class VenteController {
}
