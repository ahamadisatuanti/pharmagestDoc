package example.pharmagest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class DbFonctions {
    public Connection connct_to_db(String id, String mdp) {
        Connection conn=null;
        try {
             Class.forName("org.postgresql.Driver");
             conn= DriverManager.getConnection("jdbc:postgresql://localhost:5432/DbPharamacie",id,mdp);
             if(conn!=null){
                 System.out.println("Connexion établie");
             }
             else{
                 System.out.println("Connexion échouée");
             }



        }catch(Exception e){
            System.out.println(e);
        }
        return conn;
    }

    public void créerTable(Connection conn, String nom_table){
        Statement déclaration;
        try {
            String query="create table "+nom_table+"(identifiant SERIAL, nom varchar(50), prénom varchar(50), motDePasse varchar(20), poste varchar(20), primary key(identifiant));";
        déclaration= conn.createStatement();
        déclaration.executeUpdate(query);
        System.out.println("Table créée");
        }catch (Exception e){
            System.out.println(e);
        }
    }


    public void insérer_ligne(Connection conn, String nom_table, String nom, String prénom, String mdp, String poste){
        Statement déclaration;
        try {
            String query=String.format("INSERT INTO %s(nom,prénom,motDePasse,poste) values('%s','%s','%s','%s');",nom_table,nom,prénom,mdp,poste);
            déclaration= conn.createStatement();
            déclaration.executeUpdate(query);
            System.out.println("Ligne ajoutée");
        }catch (Exception e){
            System.out.println(e);
        }
    }


    public void lire_tab(Connection conn, String nom_table){
        Statement déclaration;
        ResultSet res=null;
        try {

            String query=String.format("SELECT * from %s",nom_table);
            déclaration= conn.createStatement();
            res=déclaration.executeQuery(query);
            while (res.next()){
                System.out.print("identifiant : "+res.getString("identifiant")+" -> ");
                System.out.print("nom : "+res.getString("nom")+" -> ");
                System.out.print("prénom : "+res.getString("prénom")+" -> ");
                System.out.print("motDepasse : "+res.getString("motDePasse")+" -> ");
                System.out.println("poste : "+res.getString("poste")+" ");
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }


    public void recherche (Connection conn, String nom_table, String nom){
        Statement déclaration;
        ResultSet res=null;
        try {
            String query=String.format("SELECT * from %s where nom= '%s'",nom_table,nom);
            déclaration= conn.createStatement();
            res=déclaration.executeQuery(query);
            while (res.next()){
                System.out.print("identifiant : "+res.getString("identifiant")+" -> ");
                System.out.print("nom : "+res.getString("nom")+" -> ");
                System.out.print("prénom : "+res.getString("prénom")+" -> ");
                System.out.print("motDepasse : "+res.getString("motDePasse")+" -> ");
                System.out.println("poste : "+res.getString("poste")+" ");
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }



    public void éditer (Connection conn, String nom_table, String motDePasse, String newMotDePasse){
        Statement déclaration;
        try {
            String query=String.format("UPDATE %s set motdepasse='%s' where motdepasse='%s'",nom_table ,newMotDePasse ,motDePasse);
            déclaration= conn.createStatement();
            déclaration.executeUpdate(query);
            System.out.println("Donnée éditée");
        }catch (Exception e){
            System.out.println(e);
        }
    }


    public void supprimer_ligne (Connection conn, String nom_table, int identifiant){
        Statement déclaration;
        try {
            String query=String.format("DELETE FROM %s where identifiant='%s'",nom_table ,identifiant);
            déclaration= conn.createStatement();
            déclaration.executeUpdate(query);
            System.out.println("Ligne supprimée");
        }catch (Exception e){
            System.out.println(e);
        }
    }




}
