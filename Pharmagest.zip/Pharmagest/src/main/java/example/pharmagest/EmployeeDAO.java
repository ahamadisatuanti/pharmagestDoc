package example.pharmagest;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeDAO {

    //*******************************
    // SÉLECTIONNER un employé
    //*******************************
    public static Employee searchEmployee(String empId) throws SQLException, ClassNotFoundException {
        // Déclarer une instruction SELECT
        String selectStmt = "SELECT * FROM public.\"Employee\" WHERE \"EMPLOYEE_ID\"=" + empId;

        // Exécuter l'instruction SELECT
        try {
            // Obtenir un ResultSet à partir de la méthode dbExecuteQuery
            ResultSet rsEmp = DBUtil.dbExecuteQuery(selectStmt);

            // Envoyer le ResultSet à la méthode getEmployeeFromResultSet et obtenir l'objet employé
            Employee employee = getEmployeeFromResultSet(rsEmp);

            // Retourner l'objet employé
            return employee;
        } catch (SQLException e) {
            System.out.println("Une erreur s'est produite lors de la recherche d'un employé avec l'identifiant " + empId + " : " + e);
            // Retourner l'exception
            throw e;
        }
    }

    // Utiliser le ResultSet de la base de données comme paramètre et définir les attributs de l'objet Employee et retourner l'objet employé.
    private static Employee getEmployeeFromResultSet(ResultSet rs) throws SQLException {
        Employee emp = null;
        if (rs.next()) {
            emp = new Employee();
            emp.setEmployeeId(rs.getInt("EMPLOYEE_ID"));
            emp.setFirstName(rs.getString("FIRST_NAME"));
            emp.setLastName(rs.getString("LAST_NAME"));
            emp.setEmail(rs.getString("EMAIL"));
            /* emp.setPhoneNumber(rs.getString("PHONE_NUMBER"));
            emp.setHireDate(rs.getDate("HIRE_DATE"));
            emp.setJobId(rs.getString("JOB_ID"));
            emp.setSalary(rs.getInt("SALARY"));
            emp.setCommissionPct(rs.getDouble("COMMISSION_PCT"));
            emp.setManagerId(rs.getInt("MANAGER_ID"));
            emp.setDepartmantId(rs.getInt("DEPARTMENT_ID")); */
        }
        return emp;
    }

    //*******************************
    // SÉLECTIONNER des employés
    //*******************************
    public static ObservableList<Employee> searchEmployees() throws SQLException, ClassNotFoundException {
        // Déclarer une instruction SELECT
        String selectStmt = "SELECT * FROM public.\"Employee\"";

        // Exécuter l'instruction SELECT
        try {
            // Obtenir un ResultSet à partir de la méthode dbExecuteQuery
            ResultSet rsEmps = DBUtil.dbExecuteQuery(selectStmt);

            // Envoyer le ResultSet à la méthode getEmployeeList et obtenir la liste d'employés
            ObservableList<Employee> empList = getEmployeeList(rsEmps);

            // Retourner la liste d'employés
            return empList;
        } catch (SQLException e) {
            System.out.println("L'opération de sélection SQL a échoué : " + e);
            // Retourner l'exception
            throw e;
        }
    }

    // Opération Select * from employees
    private static ObservableList<Employee> getEmployeeList(ResultSet rs) throws SQLException, ClassNotFoundException {
        // Déclarer une liste observable qui comprend des objets Employee
        ObservableList<Employee> empList = FXCollections.observableArrayList();

        while (rs.next()) {
            Employee emp = new Employee();
            emp.setEmployeeId(rs.getInt("EMPLOYEE_ID"));
            emp.setFirstName(rs.getString("FIRST_NAME"));
            emp.setLastName(rs.getString("LAST_NAME"));
            emp.setEmail(rs.getString("EMAIL"));
            /* emp.setPhoneNumber(rs.getString("PHONE_NUMBER"));
            emp.setHireDate(rs.getDate("HIRE_DATE"));
            emp.setJobId(rs.getString("JOB_ID"));
            emp.setSalary(rs.getInt("SALARY"));
            emp.setCommissionPct(rs.getDouble("COMMISSION_PCT"));
            emp.setManagerId(rs.getInt("MANAGER_ID"));
            emp.setDepartmantId(rs.getInt("DEPARTMENT_ID")); */
            // Ajouter l'employé à la liste observable
            empList.add(emp);
        }
        // Retourner la liste d'employés (ObservableList d'employés)
        return empList;
    }

    //*************************************
    // METTRE À JOUR l'adresse e-mail d'un employé
    //*************************************
    public static void updateEmpEmail(String empId, String empEmail) throws SQLException, ClassNotFoundException {
        // Déclarer une instruction UPDATE
        String updateStmt =
                "UPDATE public.\"Employee\"\n" +
                        "      SET \"EMAIL\" = '" + empEmail + "'\n" +
                        "    WHERE \"EMPLOYEE_ID\" = " + empId + ";\n";

        // Exécuter l'opération UPDATE
        try {
            DBUtil.dbExecuteUpdate(updateStmt);
        } catch (SQLException e) {
            System.out.print("Une erreur s'est produite lors de l'opération de MISE À JOUR : " + e);
            throw e;
        }
    }

    //*************************************
    // SUPPRIMER un employé
    //*************************************
    public static void deleteEmpWithId(String empId) throws SQLException, ClassNotFoundException {
        // Déclarer une instruction DELETE
        String updateStmt =
                "   DELETE FROM public.\"Employee\"\n" +
                        "         WHERE \"EMPLOYEE_ID\" =" + empId + ";\n";

        // Exécuter l'opération DELETE
        try {
            DBUtil.dbExecuteUpdate(updateStmt);
        } catch (SQLException e) {
            System.out.print("Une erreur s'est produite lors de l'opération de SUPPRESSION : " + e);
            throw e;
        }
    }

    //*************************************
    // INSÉRER un employé
    //*************************************
    public static void insertEmp(String name, String lastname, String email) throws SQLException, ClassNotFoundException {
        // Déclarer une instruction INSERT
        String updateStmt =
                "INSERT INTO public.\"Employee\"\n" +
                        "( \"FIRST_NAME\", \"LAST_NAME\", \"EMAIL\")\n" +
                        "VALUES\n" +
                        "('" + name + "', '" + lastname + "','" + email + "');\n";

        // Exécuter l'opération INSERT
        try {
            DBUtil.dbExecuteUpdate(updateStmt);
        } catch (SQLException e) {
            System.out.print("Une erreur s'est produite lors de l'opération d'INSERTION : " + e);
            throw e;
        }
    }
}
