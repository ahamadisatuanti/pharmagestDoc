package example.pharmagest;

/*
public class Utilisateur {
    protected int num_util;
    protected String nom_util, prenom_util, adresse_util, tel_util, email_util;
}

class pharmacien extends Utilisateur  {

}
class vendeur extends Utilisateur  {

}
class caissier extends Utilisateur  {

}*/

public class Utilisateur {

    private int numeroUtilisateur; // Clé primaire

    private String nom;

    private String prenom;

    private String adresse;

    private String telephone;

    private String email;

    public Utilisateur(int numeroUtilisateur, String nom, String prenom, String adresse, String telephone, String email) {

        this.numeroUtilisateur = numeroUtilisateur;

        this.nom = nom;

        this.prenom = prenom;

        this.adresse = adresse;

        this.telephone = telephone;

        this.email = email;

    }

    public int getNumeroUtilisateur() {

        return numeroUtilisateur;

    }

    public void setNumeroUtilisateur(int numeroUtilisateur) {

        this.numeroUtilisateur = numeroUtilisateur;

    }

    public String getNom() {

        return nom;

    }

    public void setNom(String nom) {

        this.nom = nom;

    }

    public String getPrenom() {

        return prenom;

    }

    public void setPrenom(String prenom) {

        this.prenom = prenom;

    }

    public String getAdresse() {

        return adresse;

    }

    public void setAdresse(String adresse) {

        this.adresse = adresse;

    }

    public String getTelephone() {

        return telephone;

    }

    public void setTelephone(String telephone) {

        this.telephone = telephone;

    }

    public String getEmail() {

        return email;

    }

    public void setEmail(String email) {

        this.email = email;

    }

}