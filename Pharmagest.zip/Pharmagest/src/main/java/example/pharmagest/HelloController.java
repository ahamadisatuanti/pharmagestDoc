package example.pharmagest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {

    @FXML
    private javafx.scene.control.Button Fermer;

    @FXML
    private javafx.scene.control.Button Connexion;

    @FXML
    protected void onCloseButtonClick(ActionEvent event) {
        // Fermer l'application
        System.exit(0);
    }

    @FXML
    protected void onConnexionButtonClick(ActionEvent event) {
        try {
            // Charger la vue depuis le fichier FXML "tableauDeBord.fxml"
            Parent root = FXMLLoader.load(getClass().getResource("tableauDeBord.fxml"));

            // Créer une nouvelle scène
            Scene scene = new Scene(root, 600, 400);

            // Obtenir le stage actuel à partir de l'événement
            Stage currentStage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();

            // Créer un nouveau stage pour afficher la fenêtre "tableauDeBord"
            Stage newStage = new Stage();
            newStage.setTitle("Tableau de Bord");
            newStage.setScene(scene);

            // Fermer la fenêtre actuelle
            currentStage.hide();

            // Afficher la fenêtre "tableauDeBord"
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
