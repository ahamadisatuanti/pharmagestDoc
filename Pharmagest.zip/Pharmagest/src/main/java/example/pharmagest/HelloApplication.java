package example.pharmagest;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;

public class HelloApplication extends Application {

    // Méthode principale d'entrée de l'application JavaFX
    @Override
    public void start(Stage stage) throws IOException {
        // Charger l'interface utilisateur depuis le fichier FXML "hello-view.fxml"
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("caisse.fxml"));
        Parent root = fxmlLoader.load();

        // Créer une scène
        Scene scene = new Scene(root, 520, 400);

        // Configurer le titre de la fenêtre
        stage.setTitle("Page de Connexion");

        // Associer la scène à la fenêtre principale
        stage.setScene(scene);

        // Afficher la fenêtre principale
        stage.show();
    }

    // Méthode principale d'exécution de l'application
    public static void main(String[] args) {
        // Lancer l'application JavaFX
        launch();

        //Pour se connecter à la base de donnée
         //DbFonctions db=new DbFonctions();
        //Connection conn=db.connct_to_db("postgres","nichico976");

        //Pour créer une table
       // db.créerTable(conn, "utilisateur");

        //Pour inérer une ligne
        //db.insérer_ligne(conn,"utilisateur","jadore","ledeal","non321","voleur");

        //Pour lire tableau
        //db.lire_tab(conn, "utilisateur");

        //Pour éditer une donnée
        //db.éditer(conn, "utilisateur", "mdp123", "mdp976");


        //Pour chercher une donnée
        //db.recherche(conn,"utilisateur", "jean");

        //Pour supprimer ligne
        //db.supprimer_ligne(conn,"utilisateur",4);

    }
}
